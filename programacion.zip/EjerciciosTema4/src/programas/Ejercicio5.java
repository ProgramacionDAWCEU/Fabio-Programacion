package programas;

public class Ejercicio5 {

	public static void main(String[] args) {
		
		System.out.println(getSuma(1,1));
		

	}
	
	public static Integer getSuma(int x, int y) {
		Integer suma = x+y;
		return suma;
	}

}
