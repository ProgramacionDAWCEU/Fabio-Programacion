package Alumnos;

public class Ejercicio22 {

	public static void main(String[] args) {
		

	}

}
