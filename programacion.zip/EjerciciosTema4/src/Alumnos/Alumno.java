package Alumnos;

public class Alumno extends Persona{
	
	//Atributos
	 private int dni;
	 private Integer nota;
	 private Curso c;
	 
	 
	 //Constructures
	public Alumno(int dni) {
		this.dni = dni;
	}
	
	public Alumno() {
		
	}
	public int getDni() {
		return dni;
	}
	public void setDni(int dni) {
		this.dni = dni;
	}
	
	public Integer getNota() {
		return nota;
	}
	public void setNota(Integer nota) {
		this.nota = nota;
	}
	
	//Metodos
	
	@Override
	public String toString() {
		return "Alumnos [dni=" + dni + ", nombre=" + getNombre() + ", edad=" + getEdad() + ", nota=" + nota + "]";
	}
	public Integer aprobar() {
		
		return 5;
	}
	
	
	 
	
	 
	 

}
