package Calculadora;

public class Calculadora {
	
	public static Integer getSuma(int x , int y) {
		Integer r = x + y;
		return r;
	}
	
	public static Integer getResta(int x , int y) {
		Integer r = x - y;
		return r;
	}
	
	public static Integer getMult(int x , int y) {
		Integer r = x * y;
		return r;
	}
	
	public static Integer getDiv(int x , int y) {
		Integer r = x / y;
		return r;
	}

}
