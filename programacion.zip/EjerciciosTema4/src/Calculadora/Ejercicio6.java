package Calculadora;

public class Ejercicio6 {

	public static void main(String[] args) {
		System.out.println(Calculadora.getSuma(4, 2));
		System.out.println(Calculadora.getResta(4, 2));
		System.out.println(Calculadora.getMult(4, 2));
		System.out.println(Calculadora.getDiv(4, 2));

	}

}
