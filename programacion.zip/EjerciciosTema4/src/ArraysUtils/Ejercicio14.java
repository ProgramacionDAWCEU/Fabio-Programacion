package ArraysUtils;

public class Ejercicio14 {

	public static void main(String[] args) {
		
		String cadena[] = {"cadena1", "cadena2", "cadena3"};

	}

}
