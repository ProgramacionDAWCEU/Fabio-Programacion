package ArraysUtils;

public class Ejercicio11 {

	public static void main(String[] args) {
		String array[] = {"A", "B","C"};
		System.out.println(ArrayUtils.buscarPalabra(array, "B"));

	}

}
