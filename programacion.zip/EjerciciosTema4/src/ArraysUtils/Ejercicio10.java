package ArraysUtils;

public class Ejercicio10 {

	public static void main(String[] args) {
		
		String array[] = {"A", "B","C"};
		ArrayUtils.obtenerPalabra(array, 1);

	}

}
