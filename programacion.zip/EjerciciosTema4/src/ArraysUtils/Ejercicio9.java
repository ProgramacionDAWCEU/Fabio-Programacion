package ArraysUtils;


public class Ejercicio9 {

	public static void main(String[] args) {
		
		String array[] = {"A", "B","C"};
		ArrayUtils.imprimirArray(array);

	}

	

}
