package Numeros;

public class Ejercicio13 {

	public static void main(String[] args) {
		
		System.out.println(Numeros.factorial(5));

	}

}
