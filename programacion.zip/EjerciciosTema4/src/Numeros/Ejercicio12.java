package Numeros;

public class Ejercicio12 {

	public static void main(String[] args) {
		
		System.out.println(Numeros.sumarNumeros(5));

	}

}
